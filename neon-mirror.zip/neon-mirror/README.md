# NEON MIRROR

A live webcam experience: a long, psychedelic rainbow ribbon showing your own face in heat-map colours floats in front of you and stretches between your hands. Everything runs in your browser.

## Features
- Live webcam background (mirrored), local processing only.
- MediaPipe **Hand Landmarker** (up to 2 hands) and **Face Landmarker** (face centre, scale, roll).
- Custom GLSL shaders: false-colour thermal palette, posterising, edge lines that keep the face readable, vertical rainbow stripes, chromatic aberration, wavy displacement, glitch tears, cyan/magenta edge glow.
- Subdivided 3D ribbon with curvature, ripple, taper (perspective) and idle floating.
- Controls: start/stop, status lights, intensity, animation speed, reset, fullscreen, hints toggle, FPS display.
- Adaptive quality: lowers render resolution and inference frequency on slow devices.

## Stack
React 18, TypeScript, Vite 5, Three.js 0.160, @mediapipe/tasks-vision 0.10.14.

## Prerequisites
Node.js 18 or newer and npm. A webcam. A modern browser (Chrome, Edge, Safari, Firefox).

## Install and run
```bash
npm install        # also runs `npm run setup` (copies WASM, downloads models)
npm run dev        # http://localhost:5173 (camera works on localhost)
npm run typecheck
npm run build      # type-checks, then builds to dist/
npm run preview    # serve the production build
```
To test on a phone, use an HTTPS URL (for example a deployed preview). Browsers only allow camera access on HTTPS or localhost.

## Model setup
`npm run setup` does two things:
1. Copies the MediaPipe WASM runtime from `node_modules` to `public/wasm/`.
2. Downloads `hand_landmarker.task` and `face_landmarker.task` into `public/models/` from Google's public MediaPipe model storage.

If a local file is missing (for example the download was blocked), the app falls back at runtime to the same Google URL for the models and to jsDelivr for the WASM. Re-run `npm run setup` once you have internet to self-host them. Fully offline use requires the files to exist locally.

## Deploy to Vercel
1. Run `npm install` locally once so `public/models` is filled, then commit the models if you want them self-hosted (remove the `public/models/*.task` and `public/wasm` lines from `.gitignore`, or let the CDN fallback handle it).
2. Push to GitHub and import the repo in Vercel (framework: Vite). `vercel.json` already sets the build command, output directory, SPA rewrite and a camera Permissions-Policy.
3. Or from the CLI: `npx vercel --prod`.
Any HTTPS static host works with the contents of `dist/`.

## How the hand control works
- Each hand's control point is the midpoint between thumb tip and index fingertip.
- Two hands: ribbon centre = midpoint, width = distance, rotation = line between hands, taper and yaw come from the difference in apparent hand size (a depth proxy).
- One hand: the ribbon follows it, keeps its width, and tilts with the hand.
- No hands: it holds for 0.5 s, then floats; when hands return it eases back without jumping.

## Troubleshooting
- **Camera blocked:** allow the camera in the browser's site settings (lock icon in the address bar) and reload.
- **No camera / in use:** close other apps using the camera (Zoom, Teams, other tabs).
- **Nothing happens on a phone:** the page must be HTTPS; `http://192.168.x.x` will not get camera access.
- **Models fail to load:** check your connection, or run `npm run setup`.
- **Low FPS:** the app lowers resolution automatically; closing other GPU-heavy tabs helps.

## Privacy
Video frames are processed locally by the browser and GPU. Nothing is recorded, saved, photographed or transmitted, and there are no analytics or tracking scripts. The camera is released when you press Stop or leave the page. Only the model and runtime files are downloaded.

## Project structure
```
src/components   CameraView, NeonRibbon, ControlPanel, LandingScreen, LoadingScreen, StatusIndicator, Instructions, ErrorBoundary
src/hooks        useCamera, useHandTracking, useFaceTracking, useAnimationLoop
src/three        RibbonRenderer (all Three.js objects, outside React)
src/shaders      neonRibbonVertex.glsl, neonRibbonFragment.glsl
src/utils        coordinateMapping, smoothing, gestureDetection, performance, vision
src/types        shared types
src/styles       global, landing, experience CSS
scripts/setup.mjs  WASM copy + model download
```
