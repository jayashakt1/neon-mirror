// Copies MediaPipe WASM from node_modules into public/wasm and downloads the two model files.
// Never fails the install: the app falls back to CDN URLs if a local asset is missing.
import { cpSync, existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const wasmSrc = join(root, 'node_modules/@mediapipe/tasks-vision/wasm');
const wasmDst = join(root, 'public/wasm');
if (existsSync(wasmSrc)) {
  cpSync(wasmSrc, wasmDst, { recursive: true });
  console.log('[setup] copied MediaPipe WASM -> public/wasm');
} else console.log('[setup] node_modules not installed yet; skipping WASM copy');

const models = {
  'hand_landmarker.task': 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',
  'face_landmarker.task': 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task'
};
mkdirSync(join(root, 'public/models'), { recursive: true });
for (const [name, url] of Object.entries(models)) {
  const out = join(root, 'public/models', name);
  if (existsSync(out)) { console.log('[setup] have', name); continue; }
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    writeFileSync(out, Buffer.from(await res.arrayBuffer()));
    console.log('[setup] downloaded', name);
  } catch (e) {
    console.warn(`[setup] could not download ${name} (${e.message}). The app will load it from Google's CDN at runtime. Retry with: npm run setup`);
  }
}
