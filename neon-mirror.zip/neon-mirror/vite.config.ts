import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  assetsInclude: ['**/*.task'],
  build: { target: 'es2020', chunkSizeWarningLimit: 1200 }
});
