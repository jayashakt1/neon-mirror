import { useCallback, useRef, useState } from 'react';
import CameraView from './components/CameraView';
import ControlPanel from './components/ControlPanel';
import Instructions from './components/Instructions';
import LandingScreen from './components/LandingScreen';
import LoadingScreen from './components/LoadingScreen';
import NeonRibbon from './components/NeonRibbon';
import { useAnimationLoop } from './hooks/useAnimationLoop';
import { useCamera } from './hooks/useCamera';
import { useFaceTracking } from './hooks/useFaceTracking';
import { useHandTracking } from './hooks/useHandTracking';
import type { RibbonRenderer } from './three/RibbonRenderer';
import { DEFAULT_SETTINGS, type FaceData, type RibbonPose, type Settings, type Stage, type TrackedHand, type TrackingStatus } from './types';
import { computeTarget, parseFace, parseHand } from './utils/gestureDetection';
import { AdaptiveQuality, FpsMeter } from './utils/performance';
import { approach } from './utils/smoothing';

const startPose = (): RibbonPose => ({ x: 0, y: -0.7, w: 5, ang: 0, ry: 0, taper: 0 });
const MAX_DPR = /Mobi|Android/i.test(navigator.userAgent) ? 1.5 : 2;

export default function App() {
  const camera = useCamera();
  const hand = useHandTracking();
  const face = useFaceTracking();
  const [stage, setStage] = useState<Stage>('landing');
  const [loadingMsg, setLoadingMsg] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [status, setStatus] = useState<TrackingStatus>({ camera: false, hands: 0, face: false, fps: 60 });

  const rendererRef = useRef<RibbonRenderer | null>(null);
  const settingsRef = useRef(settings); settingsRef.current = settings;
  const quality = useRef(new AdaptiveQuality(Math.min(window.devicePixelRatio || 1, MAX_DPR)));
  const fps = useRef(new FpsMeter());
  const engine = useRef({
    hands: [] as TrackedHand[], lastHand: -9, face: null as FaceData | null,
    lastVT: -1, frame: 0, cur: startPose(), tgt: startPose()
  });
  const getPixelRatio = useCallback(() => quality.current.pixelRatio, []);

  const stopCamera = camera.stop;
  const fail = useCallback((message: string) => {
    stopCamera(); setError(message); setStage('landing');
  }, [stopCamera]);

  const start = async () => {
    setError(null); setStage('loading'); setLoadingMsg('Starting your camera…');
    try { await camera.start(); } catch (e) { fail((e as Error).message); return; }
    setLoadingMsg('Loading hand and face models…');
    try { await hand.load(); } catch { fail('The hand-tracking model could not be loaded. Check your internet connection and try again.'); return; }
    await face.load(); // optional: the ribbon still works without face focus
    engine.current = { ...engine.current, hands: [], lastHand: -9, face: null, lastVT: -1, frame: 0 };
    setSettings(s => ({ ...s, showHelp: true }));
    setStage('live');
  };
  const stop = () => { camera.stop(); setStage('landing'); };
  const reset = () => {
    setSettings(DEFAULT_SETTINGS);
    engine.current.cur = startPose(); engine.current.tgt = startPose(); engine.current.lastHand = -9;
  };

  useAnimationLoop((now, dt) => {
    const r = rendererRef.current, v = camera.videoRef.current;
    if (!r || !v) return;
    const e = engine.current, t = now / 1000;

    // Run inference at most once per new video frame, less often if the device is slow.
    if (v.readyState >= 2 && v.currentTime !== e.lastVT) {
      e.lastVT = v.currentTime; e.frame++;
      const every = quality.current.trackEvery;
      if (e.frame % every === 0) {
        const hl = hand.detect(v, now);
        if (hl) { e.hands = hl.map(l => parseHand(l, r.view)); if (hl.length) e.lastHand = t; }
        if (e.frame % (every * 2) === 0) { const fl = face.detect(v, now); if (fl) e.face = parseFace(fl, t); }
      }
    }

    computeTarget(e.hands, e.lastHand, t, r.view, e.tgt);
    const c = e.cur, g = e.tgt;
    c.x = approach(c.x, g.x, 14, dt); c.y = approach(c.y, g.y, 14, dt);
    c.w = approach(c.w, g.w, 9, dt); c.ang = approach(c.ang, g.ang, 12, dt);
    c.ry = approach(c.ry, g.ry, 12, dt); c.taper = approach(c.taper, g.taper, 12, dt);
    const s = settingsRef.current;
    r.render(c, e.face, dt, t, s.intensity, s.speed);

    if (fps.current.tick(dt)) {
      if (quality.current.update(fps.current.fps, 0.5)) r.setPixelRatio(quality.current.pixelRatio);
      setStatus({ camera: true, hands: t - e.lastHand < 0.5 ? e.hands.length : 0, face: e.face !== null && t - e.face.t < 0.6, fps: fps.current.fps });
    }
  }, stage === 'live');

  return (
    <>
      <CameraView videoRef={camera.videoRef} live={stage === 'live'} />
      {stage === 'landing' && <LandingScreen onStart={start} error={error} />}
      {stage === 'loading' && <LoadingScreen message={loadingMsg} />}
      {stage === 'live' && (
        <>
          <NeonRibbon videoRef={camera.videoRef} rendererRef={rendererRef} getPixelRatio={getPixelRatio} onError={fail} />
          <ControlPanel settings={settings} status={status} onChange={p => setSettings(s => ({ ...s, ...p }))} onReset={reset} onStop={stop} />
          {settings.showHelp && <Instructions onHide={() => setSettings(s => ({ ...s, showHelp: false }))} />}
        </>
      )}
    </>
  );
}
