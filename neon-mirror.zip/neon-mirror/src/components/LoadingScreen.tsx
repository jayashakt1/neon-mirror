export default function LoadingScreen({ message }: { message: string }) {
  return (
    <div className="loading" role="status" aria-live="polite">
      <div className="loading-bar" aria-hidden="true" />
      <p>{message}</p>
    </div>
  );
}
