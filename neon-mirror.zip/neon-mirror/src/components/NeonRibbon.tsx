import { useEffect, useRef, type MutableRefObject, type RefObject } from 'react';
import { RibbonRenderer } from '../three/RibbonRenderer';

interface Props {
  videoRef: RefObject<HTMLVideoElement>;
  rendererRef: MutableRefObject<RibbonRenderer | null>;
  getPixelRatio: () => number;
  onError: (message: string) => void;
}

/** Hosts the WebGL canvas. All drawing happens in RibbonRenderer, outside React's render cycle. */
export default function NeonRibbon({ videoRef, rendererRef, getPixelRatio, onError }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current, video = videoRef.current;
    if (!canvas || !video) return;
    let renderer: RibbonRenderer;
    try { renderer = new RibbonRenderer(canvas, video, onError); }
    catch { onError('WebGL is not available in this browser, so the ribbon cannot be drawn.'); return; }
    rendererRef.current = renderer;
    const fit = () => renderer.resize(window.innerWidth, window.innerHeight, getPixelRatio());
    fit();
    window.addEventListener('resize', fit);
    window.addEventListener('orientationchange', fit);
    return () => {
      window.removeEventListener('resize', fit);
      window.removeEventListener('orientationchange', fit);
      rendererRef.current = null;
      renderer.dispose();
    };
  }, [videoRef, rendererRef, getPixelRatio, onError]);

  return <canvas ref={canvasRef} className="stage-canvas" />;
}
