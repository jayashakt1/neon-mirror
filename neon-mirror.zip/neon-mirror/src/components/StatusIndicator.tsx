export default function StatusIndicator({ label, on, detail }: { label: string; on: boolean; detail?: string }) {
  return (
    <div className="status" role="status">
      <span className={`status-dot${on ? ' on' : ''}`} aria-hidden="true" />
      <span>{label}</span>
      {detail !== undefined && <span className="status-detail">{detail}</span>}
      <span className="sr-only">{on ? 'active' : 'inactive'}</span>
    </div>
  );
}
