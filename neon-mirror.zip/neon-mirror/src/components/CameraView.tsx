import type { RefObject } from 'react';

/** Mirrored full-screen webcam preview. The same element feeds MediaPipe and the shader texture. */
export default function CameraView({ videoRef, live }: { videoRef: RefObject<HTMLVideoElement>; live: boolean }) {
  return <video ref={videoRef} className={`camera${live ? ' is-live' : ''}`} playsInline muted autoPlay aria-hidden="true" />;
}
