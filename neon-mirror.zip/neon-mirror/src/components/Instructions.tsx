export default function Instructions({ onHide }: { onHide: () => void }) {
  return (
    <aside className="hints" aria-label="How to control the ribbon">
      <p>Move your hands apart to stretch the ribbon.</p>
      <p>Raise one hand to tilt it.</p>
      <p>Move both hands to control the effect.</p>
      <button className="btn btn-small" onClick={onHide}>Hide hints</button>
    </aside>
  );
}
