import { useEffect, useState } from 'react';
import type { Settings, TrackingStatus } from '../types';
import StatusIndicator from './StatusIndicator';

interface Props {
  settings: Settings; status: TrackingStatus;
  onChange: (patch: Partial<Settings>) => void; onReset: () => void; onStop: () => void;
}

export default function ControlPanel({ settings, status, onChange, onReset, onStop }: Props) {
  const [open, setOpen] = useState(() => !window.matchMedia('(max-width: 700px)').matches);
  const [fullscreen, setFullscreen] = useState(false);
  const [fsNote, setFsNote] = useState('');

  useEffect(() => {
    const sync = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', sync);
    return () => document.removeEventListener('fullscreenchange', sync);
  }, []);

  const toggleFullscreen = async () => {
    setFsNote('');
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch { setFsNote('Fullscreen is not supported here.'); }
  };

  return (
    <div className={`panel${open ? ' open' : ''}`}>
      <button className="btn panel-toggle" aria-expanded={open} onClick={() => setOpen(o => !o)}>{open ? 'Hide controls' : 'Controls'}</button>
      {open && (
        <div className="panel-body">
          <StatusIndicator label="Camera" on={status.camera} />
          <StatusIndicator label="Hands" on={status.hands > 0} detail={String(status.hands)} />
          <StatusIndicator label="Face" on={status.face} />
          <label className="field">Effect intensity
            <input type="range" min="0.2" max="1.5" step="0.05" value={settings.intensity} onChange={e => onChange({ intensity: Number(e.target.value) })} />
          </label>
          <label className="field">Animation speed
            <input type="range" min="0.25" max="2" step="0.05" value={settings.speed} onChange={e => onChange({ speed: Number(e.target.value) })} />
          </label>
          <label className="check"><input type="checkbox" checked={settings.showHelp} onChange={e => onChange({ showHelp: e.target.checked })} /> Show hints</label>
          <label className="check"><input type="checkbox" checked={settings.showDebug} onChange={e => onChange({ showDebug: e.target.checked })} /> Show FPS</label>
          {settings.showDebug && <div className="debug">{Math.round(status.fps)} fps</div>}
          <div className="row">
            <button className="btn btn-small" onClick={onReset}>Reset effect</button>
            <button className="btn btn-small" onClick={toggleFullscreen}>{fullscreen ? 'Exit fullscreen' : 'Fullscreen'}</button>
            <button className="btn btn-small btn-stop" onClick={onStop}>Stop</button>
          </div>
          {fsNote && <p className="note">{fsNote}</p>}
        </div>
      )}
    </div>
  );
}
