interface Props { onStart: () => void; error: string | null }

export default function LandingScreen({ onStart, error }: Props) {
  return (
    <div className="landing">
      <div className="ribbon-preview" aria-hidden="true"><span /></div>
      <header className="landing-head"><span className="wordmark">NEON MIRROR</span></header>
      <main className="landing-main">
        <h1>NEON<br />MIRROR</h1>
        <p className="lede">Your hands. Your face. A living rainbow dimension.</p>
        <p className="body">Hold up both hands and a ribbon of heat-map colour stretches between them, showing your live face. Everything runs on your own device.</p>
        <button className="btn btn-primary" onClick={onStart}>START EXPERIENCE</button>
        {error && <p className="error" role="alert">{error}</p>}
        <p className="fine">Your browser will ask for camera access. This works on HTTPS pages and on localhost.</p>
      </main>
      <section className="gestures" aria-label="Hand gestures">
        <p><strong>Two hands apart</strong> stretches the ribbon; closer makes it narrow.</p>
        <p><strong>One hand higher</strong> tilts it. Move both hands to carry it around.</p>
        <p><strong>One hand only</strong> and the ribbon follows it. No hands and it floats.</p>
      </section>
      <footer className="landing-foot">Video stays in your browser. Nothing is recorded, uploaded or stored, and there is no analytics.</footer>
    </div>
  );
}
