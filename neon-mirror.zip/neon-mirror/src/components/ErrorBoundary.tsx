import { Component, type ErrorInfo, type ReactNode } from 'react';

interface State { error: Error | null }

export default class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { error: null };
  static getDerivedStateFromError(error: Error): State { return { error }; }
  componentDidCatch(error: Error, info: ErrorInfo): void { console.error('NEON MIRROR crashed', error, info.componentStack); }
  render(): ReactNode {
    if (!this.state.error) return this.props.children;
    return (
      <div className="fatal" role="alert">
        <h1>Something broke</h1>
        <p>{this.state.error.message}</p>
        <button className="btn" onClick={() => location.reload()}>Reload the page</button>
      </div>
    );
  }
}
