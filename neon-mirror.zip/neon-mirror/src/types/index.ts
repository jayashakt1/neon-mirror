export interface TrackedHand {
  x: number; y: number;      // thumb/index control point (world units)
  px: number; py: number;    // palm centre (world units)
  size: number;              // apparent hand size, a proxy for depth
  angle: number;             // wrist -> middle-knuckle direction
}
export interface FaceData {
  x: number; y: number;      // face centre in raw video coords (0..1, y down)
  w: number; h: number;      // face width / height in video coords
  roll: number;              // head roll (radians)
  t: number;                 // timestamp (s) of last detection
}
export interface RibbonPose { x: number; y: number; w: number; ang: number; ry: number; taper: number }
export interface Settings { intensity: number; speed: number; showDebug: boolean; showHelp: boolean }
export interface TrackingStatus { camera: boolean; hands: number; face: boolean; fps: number }
export type Stage = 'landing' | 'loading' | 'live';
export const DEFAULT_SETTINGS: Settings = { intensity: 1, speed: 1, showDebug: false, showHelp: true };
