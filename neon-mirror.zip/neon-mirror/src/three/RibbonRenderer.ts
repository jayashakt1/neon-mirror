import * as THREE from 'three';
import vertexShader from '../shaders/neonRibbonVertex.glsl?raw';
import fragmentShader from '../shaders/neonRibbonFragment.glsl?raw';
import type { FaceData, RibbonPose } from '../types';
import { coverScale, createView, type View } from '../utils/coordinateMapping';
import { clamp, damp } from '../utils/smoothing';

const CAM_Z = 10, FOV = 50;

/** Owns every Three.js object. Lives outside React so per-frame work never triggers re-renders. */
export class RibbonRenderer {
  readonly view: View = createView();
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 100);
  private geometry = new THREE.PlaneGeometry(1, 1, 96, 12);
  private texture: THREE.VideoTexture;
  private material: THREE.ShaderMaterial;
  private mesh: THREE.Mesh;
  private time = 0;
  private glitchAt = 2; private glitchStart = -9;
  private face = { x: 0.5, y: 0.5, w: 0.2, h: 0.3, roll: 0, has: 0 };
  private size = new THREE.Vector2();

  constructor(canvas: HTMLCanvasElement, private video: HTMLVideoElement, onShaderError: (msg: string) => void) {
    this.renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.debug.onShaderError = (gl, _program, vs, fs) => {
      onShaderError(`Shader failed to compile (${gl.getShaderInfoLog(vs) || gl.getShaderInfoLog(fs) || 'unknown error'}).`);
    };
    this.camera.position.z = CAM_Z;
    this.texture = new THREE.VideoTexture(video);
    this.texture.colorSpace = THREE.NoColorSpace;
    this.texture.minFilter = THREE.LinearFilter;
    this.texture.generateMipmaps = false;
    this.material = new THREE.ShaderMaterial({
      vertexShader, fragmentShader, side: THREE.DoubleSide,
      uniforms: {
        uVideo: { value: this.texture }, uRes: { value: new THREE.Vector2(1, 1) }, uCover: { value: new THREE.Vector2(1, 1) },
        uFace: { value: new THREE.Vector2(0.5, 0.5) }, uFaceSize: { value: new THREE.Vector2(0.2, 0.3) },
        uTime: { value: 0 }, uIntensity: { value: 1 }, uFocus: { value: 0.4 }, uGlitch: { value: 0 },
        uHasFace: { value: 0 }, uAspect: { value: 3.6 }, uRoll: { value: 0 },
        uCurve: { value: 0.3 }, uTaper: { value: 0 }, uWave: { value: 1 }
      }
    });
    this.mesh = new THREE.Mesh(this.geometry, this.material);
    this.scene.add(this.mesh);
  }

  resize(w: number, h: number, pixelRatio: number): void {
    this.renderer.setPixelRatio(pixelRatio);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    const v = this.view;
    v.screenW = w; v.screenH = h;
    v.worldH = 2 * CAM_Z * Math.tan(THREE.MathUtils.degToRad(FOV / 2)); v.worldW = v.worldH * this.camera.aspect;
    this.renderer.getDrawingBufferSize(this.size);
    (this.material.uniforms.uRes.value as THREE.Vector2).copy(this.size);
  }

  setPixelRatio(pr: number): void { this.resize(this.view.screenW, this.view.screenH, pr); }

  render(pose: RibbonPose, face: FaceData | null, dt: number, t: number, intensity: number, speed: number): void {
    const v = this.view;
    if (this.video.videoWidth) { v.videoW = this.video.videoWidth; v.videoH = this.video.videoHeight; }
    this.time += dt * speed;
    const ph = this.time;

    const hasFace = face !== null && t - face.t < 0.6;
    const f = this.face, k = damp(10, dt);
    f.has += ((hasFace ? 1 : 0) - f.has) * damp(5, dt);
    if (hasFace && face) {
      f.x += (face.x - f.x) * k; f.y += (face.y - f.y) * k; f.w += (face.w - f.w) * k; f.h += (face.h - f.h) * k; f.roll += (face.roll - f.roll) * k;
    }

    const h = clamp(pose.w / 3.6, v.worldH * 0.1, v.worldH * 0.36);
    this.mesh.position.set(pose.x, pose.y + Math.sin(ph * 0.8) * v.worldH * 0.012, Math.sin(ph * 0.5) * 0.2);
    this.mesh.rotation.set(Math.sin(ph * 0.6) * 0.06, pose.ry, pose.ang + Math.sin(ph * 0.5) * 0.02);
    this.mesh.scale.set(pose.w, h, 1);

    if (ph > this.glitchAt) { this.glitchAt = ph + 3 + Math.random() * 4; this.glitchStart = ph; }
    const glitch = Math.max(0, 1 - (ph - this.glitchStart) / 0.28);

    const u = this.material.uniforms;
    u.uTime.value = ph; u.uIntensity.value = intensity; u.uGlitch.value = glitch * intensity;
    u.uAspect.value = pose.w / h; u.uTaper.value = pose.taper;
    u.uCurve.value = 0.25 + Math.sin(ph * 0.7) * 0.12; u.uWave.value = 0.6 + 0.4 * intensity;
    u.uHasFace.value = f.has; u.uRoll.value = f.roll;
    (u.uFace.value as THREE.Vector2).set(f.x, 1 - f.y);
    (u.uFaceSize.value as THREE.Vector2).set(Math.max(0.05, f.w), Math.max(0.05, f.h));
    const c = coverScale(v); (u.uCover.value as THREE.Vector2).set(c[0], c[1]);
    this.renderer.render(this.scene, this.camera);
  }

  dispose(): void {
    this.scene.remove(this.mesh);
    this.geometry.dispose(); this.material.dispose(); this.texture.dispose();
    this.renderer.dispose(); this.renderer.forceContextLoss();
  }
}
