import { useCallback, useEffect, useRef } from 'react';
import { HandLandmarker, type NormalizedLandmark } from '@mediapipe/tasks-vision';
import { getFileset, modelUrl } from '../utils/vision';

export function useHandTracking() {
  const ref = useRef<HandLandmarker | null>(null);
  const loading = useRef<Promise<void> | null>(null);

  const load = useCallback((): Promise<void> => {
    if (ref.current) return Promise.resolve();
    if (!loading.current) {
      loading.current = (async () => {
        const [fileset, url] = await Promise.all([getFileset(), modelUrl('hand')]);
        for (const delegate of ['GPU', 'CPU'] as const) {
          try {
            ref.current = await HandLandmarker.createFromOptions(fileset, {
              baseOptions: { modelAssetPath: url, delegate }, runningMode: 'VIDEO', numHands: 2,
              minHandDetectionConfidence: 0.5, minHandPresenceConfidence: 0.5, minTrackingConfidence: 0.5
            });
            return;
          } catch (e) { if (delegate === 'CPU') throw e; }
        }
      })().finally(() => { loading.current = null; });
    }
    return loading.current;
  }, []);

  const detect = useCallback((video: HTMLVideoElement, ts: number): NormalizedLandmark[][] | null => {
    try { return ref.current ? ref.current.detectForVideo(video, ts).landmarks : null; } catch { return null; }
  }, []);

  useEffect(() => () => { ref.current?.close(); ref.current = null; }, []);
  return { load, detect };
}
