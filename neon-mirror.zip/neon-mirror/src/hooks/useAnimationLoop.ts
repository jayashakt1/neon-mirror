import { useEffect, useRef } from 'react';

/** One requestAnimationFrame loop while `active`; the callback is read from a ref so it never restarts. */
export function useAnimationLoop(callback: (nowMs: number, dt: number) => void, active: boolean): void {
  const cb = useRef(callback);
  cb.current = callback;
  useEffect(() => {
    if (!active) return;
    let raf = 0, last = performance.now();
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      const dt = Math.min(0.1, (now - last) / 1000); last = now;
      cb.current(now, dt);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active]);
}
