import { useCallback, useEffect, useRef, useState } from 'react';

export type CameraState = 'idle' | 'starting' | 'live' | 'error';

export function describeCameraError(e: unknown): string {
  const name = (e as { name?: string })?.name;
  switch (name) {
    case 'NotAllowedError': case 'SecurityError': return 'Camera permission was blocked. Allow camera access for this site in your browser settings, then try again.';
    case 'NotFoundError': case 'OverconstrainedError': return 'No camera was found on this device.';
    case 'NotReadableError': case 'AbortError': return 'The camera is in use by another app. Close it and try again.';
    default: return (e as Error)?.message || 'The camera could not be started.';
  }
}

export function useCamera() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const pending = useRef(false);
  const [state, setState] = useState<CameraState>('idle');

  const stop = useCallback(() => {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
    if (videoRef.current) { videoRef.current.pause(); videoRef.current.srcObject = null; }
    setState('idle');
  }, []);

  /** Throws a user-readable Error on failure. Calling twice never opens a second stream. */
  const start = useCallback(async () => {
    if (streamRef.current || pending.current) return;
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error('Camera access is not available. Open this page over HTTPS (or localhost) in a current browser.');
    }
    pending.current = true; setState('starting');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false
      });
      streamRef.current = stream;
      const v = videoRef.current;
      if (!v) throw new Error('Video element is not ready.');
      v.srcObject = stream;
      await v.play();
      setState('live');
    } catch (e) {
      streamRef.current?.getTracks().forEach(t => t.stop()); streamRef.current = null;
      setState('error');
      throw new Error(describeCameraError(e));
    } finally { pending.current = false; }
  }, []);

  useEffect(() => stop, [stop]);
  return { videoRef, state, start, stop };
}
