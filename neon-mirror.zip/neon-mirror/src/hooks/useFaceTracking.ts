import { useCallback, useEffect, useRef } from 'react';
import { FaceLandmarker, type NormalizedLandmark } from '@mediapipe/tasks-vision';
import { getFileset, modelUrl } from '../utils/vision';

export function useFaceTracking() {
  const ref = useRef<FaceLandmarker | null>(null);
  const loading = useRef<Promise<void> | null>(null);

  /** Face tracking is optional: resolves to false if the model cannot be loaded. */
  const load = useCallback(async (): Promise<boolean> => {
    if (ref.current) return true;
    if (!loading.current) {
      loading.current = (async () => {
        const [fileset, url] = await Promise.all([getFileset(), modelUrl('face')]);
        for (const delegate of ['GPU', 'CPU'] as const) {
          try {
            ref.current = await FaceLandmarker.createFromOptions(fileset, {
              baseOptions: { modelAssetPath: url, delegate }, runningMode: 'VIDEO', numFaces: 1, outputFaceBlendshapes: false
            });
            return;
          } catch (e) { if (delegate === 'CPU') throw e; }
        }
      })().finally(() => { loading.current = null; });
    }
    try { await loading.current; return true; } catch { return false; }
  }, []);

  const detect = useCallback((video: HTMLVideoElement, ts: number): NormalizedLandmark[] | null => {
    try { return ref.current?.detectForVideo(video, ts).faceLandmarks[0] ?? null; } catch { return null; }
  }, []);

  useEffect(() => () => { ref.current?.close(); ref.current = null; }, []);
  return { load, detect };
}
