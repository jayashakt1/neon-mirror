uniform float uTime, uCurve, uTaper, uWave;
varying vec2 vUv;
void main() {
  vUv = uv;
  vec3 p = position;                                   // unit plane, -0.5..0.5
  p.y *= 1.0 + uTaper * p.x * 2.0;                     // perspective-like wedge
  p.y += sin(p.x * 9.0 + uTime * 1.5) * 0.035 * uWave; // ripple along the ribbon
  p.z = uCurve * (p.x * p.x - 0.25) + sin(p.x * 5.0 - uTime * 1.1) * 0.12 * uWave;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
}
