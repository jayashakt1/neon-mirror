precision highp float;
uniform sampler2D uVideo;
uniform vec2 uRes, uCover, uFace, uFaceSize;
uniform float uTime, uIntensity, uFocus, uGlitch, uHasFace, uAspect, uRoll;
varying vec2 vUv;

vec3 hsv(vec3 c) { vec4 K = vec4(1., 2. / 3., 1. / 3., 3.); vec3 p = abs(fract(c.xxx + K.xyz) * 6. - K.www); return c.z * mix(K.xxx, clamp(p - K.xxx, 0., 1.), c.y); }
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
}
float lum(vec2 uv) { return dot(texture2D(uVideo, clamp(uv, .001, .999)).rgb, vec3(.299, .587, .114)); }

// Where in the webcam image this fragment looks: a "window" at its own screen position,
// blended toward a face-centred crop (derotated by head roll) when a face is tracked.
vec2 sourceUV(vec2 uv) {
  vec2 s = gl_FragCoord.xy / uRes;
  vec2 a = (vec2(1. - s.x, s.y) - .5) * uCover + .5;
  vec2 d = vec2(-(uv.x - .5) * uFaceSize.x * 3.2, (uv.y - .5) * uFaceSize.y * 1.4);
  float c = cos(uRoll), n = sin(uRoll);
  vec2 b = uFace + vec2(c * d.x - n * d.y, n * d.x + c * d.y);
  return mix(a, b, uFocus * uHasFace);
}
vec3 heat(vec3 L, float t) {
  return vec3(hsv(vec3(fract(1.05 - L.r * 1.25 + t * .03), 1., 1.)).r,
              hsv(vec3(fract(1.05 - L.g * 1.25 + t * .03), 1., 1.)).g,
              hsv(vec3(fract(1.05 - L.b * 1.25 + t * .03), 1., 1.)).b);
}
void main() {
  vec2 uv = vUv; float t = uTime;
  float band = floor(uv.y * 16. + floor(t * 9.));
  float g = step(.9, hash(vec2(band, floor(t * 7.)))) * uGlitch;           // glitch tears
  uv.x += g * (hash(vec2(band, t)) - .5) * .18;

  vec2 w = vec2(sin(uv.y * 14. + t * 1.6) * .006 + (noise(uv * vec2(8., 4.) + t * .3) - .5) * .02,
                cos(uv.x * 30. + t) * .004) * uIntensity;                  // wavy displacement
  vec2 base = sourceUV(uv) + w;

  float ca = .006 * (.5 + uIntensity) + g * .02;                           // chromatic aberration
  vec3 L = vec3(lum(base + vec2(ca, 0.)), lum(base), lum(base - vec2(ca, 0.)));
  L = floor(smoothstep(.08, .92, L) * 7. + .5) / 7.;                       // posterise
  vec3 col = pow(heat(L, t), vec3(.8));                                    // thermal false colour

  vec2 px = vec2(.004);                                                    // edges keep the face readable
  float e = abs(lum(base + vec2(px.x, 0.)) - lum(base - vec2(px.x, 0.))) + abs(lum(base + vec2(0., px.y)) - lum(base - vec2(0., px.y)));
  col *= (1. - smoothstep(.06, .22, e) * .85) * (1. + smoothstep(.2, .5, e) * .3);

  float st = .5 + .5 * sin(uv.x * 230. + sin(uv.y * 6. + t) * 3. + t * .6); // vertical rainbow stripes
  vec3 sc = hsv(vec3(fract(uv.x * 14. + t * .08 + uv.y * .2), 1., 1.));
  float amt = (.22 + .7 * smoothstep(.12, .42, abs(uv.x - .5))) * uIntensity;
  col = mix(col, sc, clamp(st * amt, 0., 1.));

  col *= .94 + .06 * sin(uv.y * 400. + t * 8.);
  float ed = min(min(uv.x * uAspect, (1. - uv.x) * uAspect), min(uv.y, 1. - uv.y));
  col += mix(vec3(0., .94, 1.), vec3(1., .17, .84), uv.x) * exp(-ed * 36.) * .9; // cyan/magenta edge glow
  gl_FragColor = vec4(col, 1.);
}
