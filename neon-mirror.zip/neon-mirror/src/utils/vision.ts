import { FilesetResolver } from '@mediapipe/tasks-vision';

const BASE = import.meta.env.BASE_URL;
const CDN_WASM = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm';
const CDN_MODELS: Record<string, string> = {
  hand: 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',
  face: 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task'
};
const LOCAL_MODELS: Record<string, string> = { hand: `${BASE}models/hand_landmarker.task`, face: `${BASE}models/face_landmarker.task` };

/** True only if the URL serves a real file (SPA fallbacks return HTML and are rejected). */
async function exists(url: string): Promise<boolean> {
  try {
    const r = await fetch(url, { method: 'HEAD' });
    return r.ok && !(r.headers.get('content-type') || '').includes('text/html');
  } catch { return false; }
}

let filesetPromise: ReturnType<typeof FilesetResolver.forVisionTasks> | null = null;
export function getFileset() {
  if (!filesetPromise) {
    filesetPromise = (async () => {
      const local = `${BASE}wasm`;
      return FilesetResolver.forVisionTasks((await exists(`${local}/vision_wasm_internal.js`)) ? local : CDN_WASM);
    })();
    filesetPromise.catch(() => { filesetPromise = null; });
  }
  return filesetPromise;
}
/** Self-hosted model if present, otherwise Google's public model CDN. */
export async function modelUrl(kind: 'hand' | 'face'): Promise<string> {
  return (await exists(LOCAL_MODELS[kind])) ? LOCAL_MODELS[kind] : CDN_MODELS[kind];
}
