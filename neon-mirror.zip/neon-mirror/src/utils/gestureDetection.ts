import type { NormalizedLandmark } from '@mediapipe/tasks-vision';
import type { FaceData, RibbonPose, TrackedHand } from '../types';
import { clamp } from './smoothing';
import { toWorld, type View } from './coordinateMapping';

export function parseHand(lm: NormalizedLandmark[], view: View): TrackedHand {
  const control = toWorld(view, (lm[4].x + lm[8].x) / 2, (lm[4].y + lm[8].y) / 2, { x: 0, y: 0 });
  let cx = 0, cy = 0;
  for (const i of [0, 5, 9, 13, 17]) { cx += lm[i].x / 5; cy += lm[i].y / 5; }
  const palm = toWorld(view, cx, cy, { x: 0, y: 0 });
  const w0 = toWorld(view, lm[0].x, lm[0].y, { x: 0, y: 0 });
  const w9 = toWorld(view, lm[9].x, lm[9].y, { x: 0, y: 0 });
  return {
    x: control.x, y: control.y, px: palm.x, py: palm.y,
    size: Math.hypot(lm[0].x - lm[9].x, lm[0].y - lm[9].y),
    angle: Math.atan2(w9.y - w0.y, w9.x - w0.x)
  };
}

export function parseFace(lm: NormalizedLandmark[], t: number): FaceData {
  const l = lm[234], r = lm[454], top = lm[10], chin = lm[152];
  return {
    x: (l.x + r.x) / 2, y: (top.y + chin.y) / 2,
    w: Math.abs(r.x - l.x), h: Math.abs(chin.y - top.y),
    roll: Math.atan2(r.y - l.y, r.x - l.x), t
  };
}

/** Writes the desired ribbon pose into `tgt` based on the hands currently tracked. */
export function computeTarget(hands: TrackedHand[], lastSeen: number, t: number, view: View, tgt: RibbonPose): void {
  const fresh = t - lastSeen < 0.5;
  if (hands.length >= 2 && fresh) {
    const a = hands[0], b = hands[1];
    const [L, R] = a.x <= b.x ? [a, b] : [b, a];
    const dx = R.x - L.x, dy = R.y - L.y;
    tgt.x = (L.x + R.x) / 2; tgt.y = (L.y + R.y) / 2;
    tgt.w = clamp(Math.hypot(dx, dy) * 1.12, view.worldW * 0.22, view.worldW * 1.7);
    tgt.ang = clamp(Math.atan2(dy, dx), -1.3, 1.3);
    tgt.ry = clamp((L.size - R.size) * 6, -0.7, 0.7);
    tgt.taper = clamp((L.size - R.size) * 7, -0.55, 0.55);
  } else if (hands.length === 1 && fresh) {
    const h = hands[0];
    tgt.x = h.x; tgt.y = h.y;
    tgt.ang = clamp((h.angle - Math.PI / 2) * 0.7, -1, 1);
    tgt.ry = 0; tgt.taper = 0;               // width is preserved
  } else if (!fresh) {                       // idle float after the 0.5 s hold window
    tgt.x = Math.sin(t * 0.4) * view.worldW * 0.06;
    tgt.y = -view.worldH * 0.12 + Math.sin(t * 0.6) * view.worldH * 0.03;
    tgt.w = view.worldW * 0.5; tgt.ang = Math.sin(t * 0.5) * 0.12;
    tgt.ry = Math.sin(t * 0.3) * 0.2; tgt.taper = 0;
  }
}
