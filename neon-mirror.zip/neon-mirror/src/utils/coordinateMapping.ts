export interface View {
  videoW: number; videoH: number;   // intrinsic video size
  screenW: number; screenH: number; // viewport size
  worldW: number; worldH: number;   // visible world size at z = 0
}
export const createView = (): View => ({ videoW: 16, videoH: 9, screenW: 16, screenH: 9, worldW: 10, worldH: 6 });

/** Raw video coords (0..1, y down, un-mirrored) -> world coords, honouring object-fit: cover and the selfie mirror. */
export function toWorld(v: View, x: number, y: number, out: { x: number; y: number }): { x: number; y: number } {
  const va = v.videoW / v.videoH, sa = v.screenW / v.screenH;
  let sx = 1 - x, sy = y;
  if (sa > va) sy = (y - 0.5) * (sa / va) + 0.5; else sx = (sx - 0.5) * (va / sa) + 0.5;
  out.x = (sx - 0.5) * v.worldW; out.y = (0.5 - sy) * v.worldH;
  return out;
}
/** Scale that maps mirrored screen UV to video UV for object-fit: cover. */
export function coverScale(v: View): [number, number] {
  const va = v.videoW / v.videoH, sa = v.screenW / v.screenH;
  return sa > va ? [1, va / sa] : [sa / va, 1];
}
