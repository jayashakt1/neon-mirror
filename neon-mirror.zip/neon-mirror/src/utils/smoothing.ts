export const clamp = (v: number, a: number, b: number): number => Math.min(b, Math.max(a, v));
/** Frame-rate independent exponential smoothing factor. */
export const damp = (rate: number, dt: number): number => 1 - Math.exp(-rate * dt);
export const approach = (cur: number, target: number, rate: number, dt: number): number => cur + (target - cur) * damp(rate, dt);
