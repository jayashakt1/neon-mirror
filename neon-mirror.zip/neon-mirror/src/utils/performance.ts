/** FPS counter that reports roughly twice per second. */
export class FpsMeter {
  fps = 60; private acc = 0; private n = 0;
  tick(dt: number): boolean {
    this.acc += dt; this.n++;
    if (this.acc < 0.5) return false;
    this.fps = this.n / this.acc; this.acc = 0; this.n = 0; return true;
  }
}
/** Lowers render resolution and inference frequency when the device struggles. */
export class AdaptiveQuality {
  level = 2; private low = 0; private high = 0;
  constructor(private maxDpr: number) {}
  get pixelRatio(): number { return this.maxDpr * [0.55, 0.8, 1][this.level]; }
  get trackEvery(): number { return [3, 2, 1][this.level]; }
  /** Returns true when the level changed. */
  update(fps: number, elapsed: number): boolean {
    if (fps < 24) { this.low += elapsed; this.high = 0; } else if (fps > 52) { this.high += elapsed; this.low = 0; } else { this.low = this.high = 0; }
    if (this.low > 2 && this.level > 0) { this.level--; this.low = 0; return true; }
    if (this.high > 8 && this.level < 2) { this.level++; this.high = 0; return true; }
    return false;
  }
}
